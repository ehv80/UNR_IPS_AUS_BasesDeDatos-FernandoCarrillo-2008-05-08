create sequence nro_emp
start with 8000;

create sequence nro_dept
start with 50
increment by 10;
