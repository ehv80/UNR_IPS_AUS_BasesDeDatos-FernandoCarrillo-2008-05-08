insert into emp
values ( null, null, null, null, null, null, null, null )
/
