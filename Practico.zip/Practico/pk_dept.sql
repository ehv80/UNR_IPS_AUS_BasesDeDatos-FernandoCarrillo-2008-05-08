alter table dept
add constraint dept_pk
primary key ( deptno )
/
