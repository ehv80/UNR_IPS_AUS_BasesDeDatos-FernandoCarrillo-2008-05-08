insert into emp
values ( 7654, 'MARTIN', 'SALESMAN', 7698, '28-SEP-81', 1250, 1400, 30 )
/
