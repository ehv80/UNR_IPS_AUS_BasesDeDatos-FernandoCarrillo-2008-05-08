alter table emp
add constraint emp_pk
primary key ( empno )
/
