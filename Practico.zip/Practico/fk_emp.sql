alter table emp
add constraint manager_fk
foreign key ( mgr ) references emp
/
