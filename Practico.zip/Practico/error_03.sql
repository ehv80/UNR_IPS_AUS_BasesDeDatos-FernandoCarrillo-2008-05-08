insert into emp
values ( 7655, 'MARTIN', 'SALESMAN', 2698, '28-SEP-81', 1250, 1400, 30 )
/
