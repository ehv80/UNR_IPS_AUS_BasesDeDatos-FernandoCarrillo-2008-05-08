insert into emp
values ( null, 'MARTIN', 'SALESMAN', 7698, '28-SEP-81', 1250, 1400, 30 )
/
